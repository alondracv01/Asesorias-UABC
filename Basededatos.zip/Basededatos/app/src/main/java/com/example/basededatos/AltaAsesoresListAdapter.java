package com.example.basededatos;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class AltaAsesoresListAdapter extends ArrayAdapter<AltaAsesores> {
    private static final String TAG = "AltaAsesoresListAdapter";
    private Context mContext;
    int mResource;

    public AltaAsesoresListAdapter(@NonNull Context context, int resource, @NonNull ArrayList<AltaAsesores> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        String nombre = getItem(position).getNombre();
        String correo = getItem(position).getCorreo();
        String materias = getItem(position).getMaterias();
        String promedio = getItem(position).getPromedio();

        AltaAsesores altaAsesores = new AltaAsesores(nombre,correo,materias,promedio);

        LayoutInflater inflater = LayoutInflater.from(mContext);
        convertView = inflater.inflate(mResource, parent, false);

        TextView tvNombre = (TextView) convertView.findViewById(R.id.nombreTextView);
        TextView tvCorreo = (TextView) convertView.findViewById(R.id.correoTextView);
        TextView tvMaterias = (TextView) convertView.findViewById(R.id.materiasTextView);
        TextView tvPromedio = (TextView) convertView.findViewById(R.id.promedioTextView);

        tvNombre.setText(nombre);
        tvCorreo.setText(correo);
        tvMaterias.setText(materias);
        tvPromedio.setText(promedio);

        return convertView;
    }
}
