package com.example.basededatos;


public class AltaAsesores {
    private String nombre;
    private String correo;
    private String promedio;
    private String materias;

    public AltaAsesores(String nombre, String correo, String materias, String promedio) {
        this.nombre = nombre;
        this.correo = correo;
        this.materias = materias;
        this.promedio = promedio;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getMaterias() {
        return materias;
    }

    public void setMaterias(String materias) {
        this.materias = materias;
    }

    public String getPromedio() {
        return promedio;
    }

    public void setPromedio(String promedio) {this.promedio = promedio;
    }

}
