package com.example.basededatos;


import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;
import androidx.fragment.app.Fragment;

import java.util.ArrayList;
import java.util.List;

public class AltaAsesoresFragment extends Fragment{
    private SQLiteDatabase db;

    private String matricula = "";
    private String matriculaAsesor = "";
    private String materias = "";
    private AltaAsesores asesorAlta;
    private ArrayList<AltaAsesores> mLista = new ArrayList<>();
    private ListView pAltaAsesores;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_altaasesores, container, false);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        matricula = "1234567";

        SQLiteOpenHelper AltaAsesoresDatabaseHelper = new AltaAsesoresDatabaseHelper(getContext());
        try{
            db = AltaAsesoresDatabaseHelper.getReadableDatabase();
            Cursor fila=db.rawQuery("select NOMBRE, CORREO, MATERIAS, MATRICULA from ALTAASESORES",null);
            while(fila.moveToNext()) {
                matriculaAsesor = fila.getString(3);
                asesorAlta = new AltaAsesores(fila.getString(0), fila.getString(1), fila.getString(2), fila.getString(3));
                mLista.add(asesorAlta);
            }
            fila.close();
            db.close();
        } catch (SQLiteException e){
            Toast toast = Toast.makeText(getContext(), "Database unavaible: onCreate", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    @Override
    public void onStart(){
        super.onStart();
        View view = getView();

        pAltaAsesores = (ListView) view.findViewById(R.id.altaAsesoresListView);

        AltaAsesoresListAdapter adapter = new AltaAsesoresListAdapter(getContext(), R.layout.adapter_view_layout, mLista);
        pAltaAsesores.setAdapter(adapter);
    }
}
